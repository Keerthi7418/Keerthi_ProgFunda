package com.gradedproject.q2;

public class Power {
	
	public static int powerOfValue(int a,int b)

	{

		if(b==0) 
			
		{
			
		return 1;
		
		}
		
		else 
			
		{
			
			return a*powerOfValue(a,b-1);
			
		}
		
	}

	public static void main(String[] args) 

	{
		int result=powerOfValue(3,9);

		System.out.println("A power B is:"+ result);
	}

}
