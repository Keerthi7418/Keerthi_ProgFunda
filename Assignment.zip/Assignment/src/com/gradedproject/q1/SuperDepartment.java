package com.gradedproject.q1;

public class SuperDepartment 

{
	
	String departmentName() 
	
	 {
	
		return "Super Department";
		
	 }
	
    String getTodaysWork() 
    
     {

		return "No Work as of now";
	 }

    String getWorkDeadline() 
    
     {
		
		return "Nil";
	 }

    String isTodayAHoliday() 
    
     {
		
		return "Today is not a holiday";
	 }


}
