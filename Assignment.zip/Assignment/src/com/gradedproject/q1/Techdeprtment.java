package com.gradedproject.q1;

public class Techdeprtment extends SuperDepartment

{

	String departmentName() 
	{
		
	    return "Tech Department";
    } 

    String getTodaysWork() 
    {
	
	    return "Complete coding of module 1";
    }

    String getWorkDeadline() 
    {
	
	    return "Complete by EOD";
    }

    String getTechStackInformation() 
    {
	
	    return "core Java";
    }

      public static void main(String[] args) 
      
      {
  		
  		Admindepatment Admindept  = new Admindepatment();
  		Hrdeprtment  Hrdept = new Hrdeprtment();
  		Techdeprtment Techdept =  new Techdeprtment();
  		
  		System.out.println("Welcome to " + Admindept.departmentName());
  		System.out.println(Admindept.getTodaysWork());
  		System.out.println(Admindept.getWorkDeadline());
  		System.out.println(Admindept.isTodayAHoliday());
  		
  		System.out.println();
  		
  		System.out.println("Welcome to " + Hrdept.departmentName());
  		System.out.println(Hrdept.doActivity());
  		System.out.println(Hrdept.getWorkDeadline());
  		System.out.println(Techdept.getWorkDeadline());
  		System.out.println(Hrdept.isTodayAHoliday());
  		
  		System.out.println();
  		
  		System.out.println("Welcome to " + Techdept.departmentName());
  		System.out.println(Techdept.getTodaysWork());
  		System.out.println(Techdept.getWorkDeadline());
  		System.out.println(Techdept.getTechStackInformation());
  		System.out.println(Techdept.isTodayAHoliday());
  		
  		
  	}

}
