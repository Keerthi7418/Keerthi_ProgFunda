package com.gradedproject.q1;

public class Hrdeprtment extends SuperDepartment

{
	
	String departmentName() 
	{
		
		return "HR Department";
	}
	
    String getTodaysWork() 
    {
		
		return "Complete your documents Submission";
	}
     
    String getWorkDeadline() 
    {
		
		return "Fill Todays timesheet and mark your attendance";
	}
 
    String doActivity() 
    {
		
		return "Team Lunch";
	}

}
